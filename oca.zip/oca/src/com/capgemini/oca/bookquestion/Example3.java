package com.capgemini.oca.bookquestion;

public class Example3 {

	public static void main(String[] args) {
		char[] ca= {74};

	}

}
