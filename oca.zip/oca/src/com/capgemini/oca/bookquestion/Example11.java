package com.capgemini.oca.bookquestion;

public class Example11 {

	public static void main(String[] args) {
    String s="JAVA";
    s=s+"rocks";
    s=s.substring(4,8);
    System.out.println(s);

	}

}
