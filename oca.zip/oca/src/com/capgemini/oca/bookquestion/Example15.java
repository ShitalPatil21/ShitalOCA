package com.capgemini.oca.bookquestion;

import java.util.ArrayList;
import java.util.List;

public class Example15 {

	public static void main(String[] args) {

   List<Integer> myList=new ArrayList<Integer>();
   myList.add(new Integer(5));
   myList.add(5);
 //  myList.add("113");
	}

}
