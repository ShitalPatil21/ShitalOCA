package com.capgemini.oca.bookquestion;

import java.util.ArrayList;

public class Example5 {

	public static void main(String[] args) {
		ArrayList<String> as=new ArrayList<>();
		as.add("apple");
		as.add("Carrot");
		as.add("banana");
		as.add(1,"plum");
		System.out.println(as);

	}

}
