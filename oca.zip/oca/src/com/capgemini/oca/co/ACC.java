package com.capgemini.oca.co;

public class ACC {
int p;
private int q;
protected int r;
public int s;

}
