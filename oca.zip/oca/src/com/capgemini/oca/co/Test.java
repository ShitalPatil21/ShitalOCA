package com.capgemini.oca.co;

import com.capgemini.oca.finalpdf.Example5;

public class Test extends Example5{
 public static void main(String[] args) {
	Example5 obj=new Test();
	
}
}
