package com.capgemini.oca.set1;

public class Example55 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String str=" ";
     str.trim();
     System.out.println(str.equals("")+":"+str.isEmpty());
     
	}

}
