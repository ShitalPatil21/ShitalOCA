package com.capgemini.oca.set1;

public class Example21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array []=new int[20];
		int array1[]= {1,2,3};
		int array2[]=new int[] {};

	}

}
