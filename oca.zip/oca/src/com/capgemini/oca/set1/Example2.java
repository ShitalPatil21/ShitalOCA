package com.capgemini.oca.set1;

public class Example2 {

	public static void main(String[] args) {
		System.out.println("Value of A is:"+(0+1));
		System.out.println("Value of B is:"+(1)+(2));

	}

}
