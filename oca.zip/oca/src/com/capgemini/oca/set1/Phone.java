package com.capgemini.oca.set1;

public class Phone {
    void call() {
    	System.out.println("Call Phone");
    }
}
