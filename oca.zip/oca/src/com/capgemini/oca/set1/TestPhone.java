package com.capgemini.oca.set1;

public class TestPhone {

	public static void main(String[] args) {
		Phone p=new Phone();
		Phone sp=new SmartPhone();
		p.call();
		sp.call();

	}

}
