package com.capgemini.oca.set1;

public class Example50 {
    static int count;
    public static void displaymsg() {
    	System.out.println("Welcome visit count"+count);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
