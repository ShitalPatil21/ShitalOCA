package com.capgemini.oca.set1;

public class Example59 {

	public static void main(String[] args) {
		String str=" Hello World";
		String str1=str.trim();
		int i=str1.indexOf(" ");
		System.out.println(i);

	}

}
