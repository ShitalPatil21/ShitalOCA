package com.capgemini.oca.set1;

abstract class Example1 {
protected void revovle() {
	
}
abstract void rotate();
}

class Earth extends Example1{

	
	 void rotate() {
		// TODO Auto-generated method stub
		
	}
	protected void revovle() {
		
	}
}