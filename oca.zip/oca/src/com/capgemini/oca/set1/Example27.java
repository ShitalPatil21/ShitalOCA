package com.capgemini.oca.set1;

public class Example27 {

	public static void main(String[] args) {
		int data[]= {2011,233,2233};
		int count=0;
		for(int e:data) {
			System.out.println(e);
			continue;
			//count++;
		}


	}

}
