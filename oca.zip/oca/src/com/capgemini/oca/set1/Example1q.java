package com.capgemini.oca.set1;

public class Example1q {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
