package com.capgemini.oca.set1;

public class TestTab {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Phone1 p=new Tab();
		Tab t=new Tab();
		System.out.println(p.keyboard);
		System.out.println(t.playMovie);
	}

}
