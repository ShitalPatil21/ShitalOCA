package com.capgemini.oca.set1;

public class Tab extends Phone1{
boolean playMovie=false;
}
