package com.capgemini.oca.set1;

public class Example24 {
	char c;
	boolean b;
	float f;

	void printAll() {
		System.out.println("C"+c);
		System.out.println("B"+b);
		System.out.println("F"+f);
	}
	public static void main(String[] args) {
		Example24 ex=new Example24();
		ex.printAll();

	}

}
