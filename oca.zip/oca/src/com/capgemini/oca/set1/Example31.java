package com.capgemini.oca.set1;

public class Example31 {
public static void main(String[] args) {
	Float f=1233.333f;
}
}
