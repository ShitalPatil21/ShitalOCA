package com.capgemini.oca.set1;

public class SmartPhone extends Phone{

	void call() {
		System.out.println("Call Smart Phone");
	}
}
