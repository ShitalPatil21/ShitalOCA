package com.capgemini.oca.set1;

public class Phone1 {
String keyboard="in-built";

}
