package com.capgemini.oca.set1;

import java.io.IOException;

public class Example4 {

	public void readContent() throws IOException {
		throw new IOException();
	}
	public static void main(String[] args) throws Exception {
		 Example4 ex=new Example4();
		  ex.readContent();

	}

}
