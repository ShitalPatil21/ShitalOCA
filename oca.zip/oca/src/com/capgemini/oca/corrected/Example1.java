package com.capgemini.oca.corrected;

public class Example1 {
	 static  int[] findMax(int[] numbers) {
		// TODO Auto-generated method stub
		return null;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int numbers[]= {12,13,14};
       int [] keys=findMax(numbers);
	}

	

}
