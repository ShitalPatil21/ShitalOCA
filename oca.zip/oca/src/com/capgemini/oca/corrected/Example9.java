package com.capgemini.oca.corrected;

public class Example9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Short s1=200;
  Integer s2=400;
 // String s3=(String)(s1+s2);
  Long s4=(long)s1+s2;
	}

}
