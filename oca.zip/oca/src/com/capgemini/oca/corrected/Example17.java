package com.capgemini.oca.corrected;
class Example17 {
protected static final int i=8;
private Example17() {
	
}
}
