package com.capgemini.oca.corrected;

public class Example41 {

	public static void main(String[] args) {
		int[] array=new int [2];
	// TODO Auto-generated method stub
       array[0]=10;
       array[1]=13;
       System.out.println( array[0]);
       System.out.println( array[1]);
	}

}
