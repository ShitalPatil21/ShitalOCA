package com.capgemini.oca.corrected;

import com.capgemini.oca.co.ACC;

public class Test extends ACC{
public static void main(String[] args) {
	Test test=new Test();
	
}
}
