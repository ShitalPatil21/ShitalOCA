package com.capgemini.oca.corrected;

public class Example80 {

	public static void main(String[] args) {
		try {
			int num=0;
			int div=0;
			int ans=num/div;
			
		} catch (RuntimeException e) {
			//ans=0;
		}
  catch (Exception e) {
	
}
		//System.out.println(ans);
	}

}
