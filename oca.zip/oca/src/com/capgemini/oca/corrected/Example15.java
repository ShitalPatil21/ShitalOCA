package com.capgemini.oca.corrected;

abstract class Example15 {

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

	int price;
	final Example15 getExample15() {
		return new Example15() {
		};
		
	}
	public int calculateprice() {
		return price;
		
	}
	public static void insertExample15() {
		
	}
}
