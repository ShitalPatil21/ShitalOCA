package com.capgemini.oca.corrected;

public class Example55 {

	public static void main(String[] args) {
//		int i=12;
//		float f=122.00f;
//		double d=23.39;
//		f=i;
		int num[][]=new int [1][3];
		for(int i=0;i<num.length;i++) {
			for(int j=0;j<num[i].length;j++) {
				System.out.println(num[i].length);
				System.out.println(num[i][j]=10);
			}
		}

	}

}
