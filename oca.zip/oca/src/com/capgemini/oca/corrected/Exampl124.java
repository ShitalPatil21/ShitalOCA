package com.capgemini.oca.corrected;

public class Exampl124 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Exampl124 ts=new Exampl124();
  System.out.println(isA);
  isA=ts.doStuff();
  System.out.println(isA);
	}

	public static boolean doStuff() {
		// TODO Auto-generated method stub
		return !isA;
	}
	static boolean isA=true;

}
