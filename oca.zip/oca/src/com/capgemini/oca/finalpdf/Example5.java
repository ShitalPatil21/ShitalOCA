package com.capgemini.oca.finalpdf;

public class Example5 {
int p;
private int q;
protected int r;
public int s;
}
