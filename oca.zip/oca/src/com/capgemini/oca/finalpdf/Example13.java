package com.capgemini.oca.finalpdf;

public class Example13 {
public static void main(String[] args) {
	String str=" ";
	str.trim();
	System.out.println(str.equals(""));
	System.out.println(str.isEmpty());
}
}
