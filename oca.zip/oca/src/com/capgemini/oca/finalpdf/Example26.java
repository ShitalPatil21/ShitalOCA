package com.capgemini.oca.finalpdf;

public class Example26 {

	public static void main(String[] args) {

		try {
			int num=10;
			int num2=0;
			int ans=num/num2;
			
		} catch (ArithmeticException ae) {
			int ans = 0;
			
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println();
	}

}
