package com.capgemini.oca.finalpdf;

public interface Downloadble {
  
	public void download();
}
